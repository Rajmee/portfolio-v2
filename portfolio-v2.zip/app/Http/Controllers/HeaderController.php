<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\HeaderSocialSettings;


class HeaderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $header_settings = HeaderSocialSettings::first();
        return view('pages.dashboard.header-settings', compact('header_settings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $header_settings = HeaderSocialSettings::firstOrNew();
        $header_settings->facebook = $request->facebook;
        $header_settings->linkedin = $request->linkedin;
        $header_settings->twitter = $request->twitter;
        $header_settings->instagram = $request->instagram;
        $header_settings->youtube = $request->youtube;

        $header_settings->save();
        return redirect()->route('admin.header')->with('success',"Data has been update successfully.");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
