<section class="achievement-area">
    <div class="container-fluid">
      <div class="row">
        <div
          class="col-lg-8 offset-lg-2 col-xl-6 offset-xl-3 col-md-8 offset-md-2 col-12"
        >
          <div class="achievement-section-head">
                <?php if(!empty ($achievement_title->section_title)): ?>
                    <span class="achieve-section-sm-title"><?php echo e($achievement_title->section_title); ?> </span>
                <?php endif; ?>

                <?php if(empty ($achievement_title->section_title)): ?>
                    <span class="achieve-section-sm-title">Section Title </span>
                <?php endif; ?>

                <?php if(!empty ($achievement_title->title)): ?>
                    <h3 class="achieve-section-big-title"><?php echo e($achievement_title->title); ?></h3>
                <?php endif; ?>

                <?php if(empty ($achievement_title->title)): ?>
                    <h3 class="achieve-section-big-title">Enter text here</h3>
                <?php endif; ?>

          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="achivement-counter-area">
            <div class="row">
              <div
                class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
                data-wow-delay="0.1s"
              >
                <div class="achievement-counter-card">
                  <h3 class="achievement-counter">
                    <?php if(!empty ($achievement_title->ach_col_1_count)): ?>
                        <span class="counter"><?php echo e($achievement_title->ach_col_1_count); ?></span>+
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_1_count)): ?>
                        <span class="counter">1000</span>+
                    <?php endif; ?>

                  </h3>

                    <?php if(!empty ($achievement_title->ach_col_1_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            <?php echo e($achievement_title->ach_col_1_title); ?>

                        </h4>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_1_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            Title text
                        </h4>
                    <?php endif; ?>

                    <?php if(!empty ($achievement_title->ach_col_1_desc)): ?>
                        <p class="achievement-count-card-text">

                        <?php echo strip_tags($achievement_title->ach_col_1_desc); ?>


                        </p>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_1_desc)): ?>
                        <h4 class="achievement-count-card-text">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum delectus esse perspiciatis laboriosam maiores dicta fugit possimus nam iste eos quod, quisquam, distinctio id, sit iusto illum perferendis ducimus rerum!
                        </h4>
                    <?php endif; ?>

                </div>
              </div>
              <div
                class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
                data-wow-delay="0.2s"
              >
                <div class="achievement-counter-card">
                  <h3 class="achievement-counter">
                    <?php if(!empty ($achievement_title->ach_col_2_count)): ?>
                        <span class="counter"><?php echo e($achievement_title->ach_col_2_count); ?></span>+
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_2_count)): ?>
                        <span class="counter">1000</span>+
                    <?php endif; ?>
                  </h3>
                    <?php if(!empty ($achievement_title->ach_col_2_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            <?php echo e($achievement_title->ach_col_2_title); ?>

                        </h4>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_2_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            Title text
                        </h4>
                    <?php endif; ?>

                    <?php if(!empty ($achievement_title->ach_col_2_desc)): ?>
                        <p class="achievement-count-card-text">

                        <?php echo strip_tags($achievement_title->ach_col_2_desc); ?>

                        </p>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_2_desc)): ?>
                        <h4 class="achievement-count-card-text">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos quos nostrum autem! Explicabo alias minus possimus quo amet impedit. Rem, fugit ipsum odio vel voluptatibus impedit blanditiis sapiente voluptates eaque?
                        </h4>
                    <?php endif; ?>
                </div>
              </div>
              <div
                class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
                data-wow-delay="0.3s"
              >
                <div class="achievement-counter-card">
                    <h3 class="achievement-counter">
                        <?php if(!empty ($achievement_title->ach_col_3_count)): ?>
                            <span class="counter"><?php echo e($achievement_title->ach_col_3_count); ?></span>+
                        <?php endif; ?>

                        <?php if(empty ($achievement_title->ach_col_3_count)): ?>
                            <span class="counter">1000</span>+
                        <?php endif; ?>
                    </h3>
                    <?php if(!empty ($achievement_title->ach_col_3_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            <?php echo e($achievement_title->ach_col_3_title); ?>

                        </h4>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_3_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            Title text
                        </h4>
                    <?php endif; ?>

                    <?php if(!empty ($achievement_title->ach_col_3_desc)): ?>
                        <p class="achievement-count-card-text">

                        <?php echo strip_tags($achievement_title->ach_col_3_desc); ?>

                        </p>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_3_desc)): ?>
                        <h4 class="achievement-count-card-text">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis ullam quidem cupiditate ipsa repellendus ducimus consequuntur officia possimus nihil quam soluta quis voluptas temporibus, debitis eaque. Animi veniam in ratione?
                        </h4>
                    <?php endif; ?>
                </div>
              </div>
              <div
                class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
                data-wow-delay="0.4s"
              >
                <div class="achievement-counter-card">
                  <h3 class="achievement-counter">
                    <?php if(!empty ($achievement_title->ach_col_4_count)): ?>
                        <span class="counter"><?php echo e($achievement_title->ach_col_4_count); ?></span>+
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_4_count)): ?>
                        <span class="counter">1000</span>+
                    <?php endif; ?>
                  </h3>
                    <?php if(!empty ($achievement_title->ach_col_4_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            <?php echo e($achievement_title->ach_col_4_title); ?>

                        </h4>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_4_title)): ?>
                        <h4 class="achievement-count-card-sm-title">
                            Title text
                        </h4>
                    <?php endif; ?>

                    <?php if(!empty ($achievement_title->ach_col_4_desc)): ?>
                        <p class="achievement-count-card-text">
                            <?php echo strip_tags($achievement_title->ach_col_4_desc); ?>
                        </p>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->ach_col_4_desc)): ?>
                        <h4 class="achievement-count-card-text">
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus doloremque amet molestiae saepe ad sed nesciunt. Autem molestias officia nemo adipisci quaerat at quibusdam perferendis sed? Sunt eos commodi temporibus?
                        </h4>
                    <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="achievement-scroll-area">
            <div class="achievement-scroll-head">
                    <?php if(!empty ($achievement_title->section_list_title)): ?>
                        <h3 class="achievement-scroll-title">
                            <img src="img/achivement-icon/badge-icon.svg" /><?php echo e($achievement_title->section_list_title); ?>

                        </h3>
                    <?php endif; ?>

                    <?php if(empty ($achievement_title->section_list_title)): ?>
                        <h3 class="achievement-scroll-title">
                            <img src="img/achivement-icon/badge-icon.svg" />Enter Text
                        </h3>
                    <?php endif; ?>
            </div>
            <div class="achievement-scroll">
              <div class="row">

                <?php $__currentLoopData = $achievement_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-lg-3 col-md-3 col-12">
                  <div class="achievement-scroll-card">

                    <?php if(!empty ($list->org_cat)): ?>
                        <span class="achi-scroll-card-sm-title"
                        ><?php echo e($list->org_cat); ?></span
                    >
                    <?php endif; ?>

                    <?php if(empty ($list->org_cat)): ?>
                        <span class="achi-scroll-card-sm-title"
                        >Software industry</span
                    >
                    <?php endif; ?>

                    <div class="achievement-company-icon">
                        <?php if(!empty ($list->org_img)): ?>
                        <a href="#" target="_blank"
                            ><img
                            src="<?php echo e($list->org_img); ?>"
                            alt="#"
                        /></a>
                        >
                        <?php endif; ?>

                        <?php if(empty ($list->org_img)): ?>
                            <a href="#" target="_blank">
                                <img src="img/about-img.jpg" alt="#" />
                            </a>
                        <?php endif; ?>

                    </div>
                    <div class="achievement-card-content">
                      <img
                        src="img/achivement-icon/badge-icon-2.svg"
                        alt="#"
                      />
                        <?php if(!empty ($list->org_title)): ?>
                            <h3 class="achievement-card-cont-title">
                                <?php echo e($list->org_title); ?>

                            </h3>
                        <?php endif; ?>

                        <?php if(empty ($list->org_title)): ?>
                            <h3 class="achievement-card-cont-title">
                               Enter Title
                            </h3>
                        <?php endif; ?>

                        <?php if(!empty ($list->org_date)): ?>
                            <span class="achievement-card-cont-date"
                            ><?php echo e($list->org_date); ?></span>
                        <?php endif; ?>

                        <?php if(empty ($list->org_date)): ?>
                            <h3 class="achievement-card-cont-title">
                               01 January, 2000
                            </h3>
                        <?php endif; ?>

                        <?php if(!empty ($list->org_desc)): ?>
                        <p class="achievement-card-cont-text">

                        <?php echo strip_tags($list->org_desc); ?>

                          </p>
                        <?php endif; ?>

                        <?php if(empty ($list->org_date)): ?>
                            <p class="achievement-card-cont-text">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                Expedita nemo voluptates quis laboriosam debitis quas quisquam.
                                Laboriosam ullam, veniam iste iusto dolore recusandae neque ipsam animi,
                                quidem voluptatum odit illum?
                            </p>
                        <?php endif; ?>

                      <div class="achievement-card-cont-btn">
                        <?php if(!empty ($list->org_button_text)): ?>
                            <a href="<?php echo e($list->org_button_url); ?>" class="theme-btn"
                            ><?php echo e($list->org_button_text); ?><i class="fi-rr-arrow-right"></i
                            ><i class="fi-rr-arrow-right"></i></a>
                        <?php endif; ?>

                        <?php if(empty ($list->org_button_text)): ?>
                            <a href="#" class="theme-btn"
                            >Award verify link<i class="fi-rr-arrow-right"></i
                            ><i class="fi-rr-arrow-right"></i
                            ></a>
                        <?php endif; ?>

                      </div>
                    </div>
                  </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/achievement.blade.php ENDPATH**/ ?>