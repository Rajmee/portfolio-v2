<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">All Business</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.home')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.business-info.all')); ?>">All Business</a>
            </li>
        </ul>
    </div>



  <div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="add-row" class="display table table-striped table-hover" >
                    <thead>
                        <tr>
                            <th>Business category</th>
                            <th>Business position</th>
                            <th>Business Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($business_info_lists)>0): ?>
                        <?php $__currentLoopData = $business_info_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php if(!empty ($info_list->business_list_title) ): ?> <?php echo e($info_list->business_list_title); ?> <?php endif; ?></td>
                            <td><?php if(!empty ($info_list->business_list_pos) ): ?> <?php echo e($info_list->business_list_pos); ?> <?php endif; ?></td>
                            <td><?php if(!empty ($info_list->business_list_comp) ): ?> <?php echo e($info_list->business_list_comp); ?> <?php endif; ?></td>

                            <td>
                                <div class="button-group">
                                   <a href="<?php echo e(route('admin.business-info.edit', $info_list->id)); ?>" class="btn btn-secondary"><i class="fi fi-rr-edit"></i></a>
                                   <form action="<?php echo e(route('admin.business-info.destroy', $info_list->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" name="submit" value="" class="btn btn-danger"><i class="fi fi-rr-trash"></i></button>
                                    </form>
                                </div>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/dashboard/business/business-all.blade.php ENDPATH**/ ?>