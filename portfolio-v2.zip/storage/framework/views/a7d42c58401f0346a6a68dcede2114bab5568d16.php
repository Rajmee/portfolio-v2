<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">All Blogs</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.home')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.blog-post.all')); ?>">All Blogs</a>
            </li>
        </ul>
    </div>



  <div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="add-row" class="display table table-striped table-hover" >
                    <thead>
                        <tr>
                            <th>Post thumbnail</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Author</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($blog_post_list)>0): ?>
                        <?php $__currentLoopData = $blog_post_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php if(!empty ($post_list->blog_img) ): ?> <div class="avatar"><img  class="avatar-img" src="<?php echo e(url($post_list->blog_img)); ?>"></div><?php endif; ?></td>
                            <td><?php if(!empty ($post_list->blog_title) ): ?> <?php echo e($post_list->blog_title); ?> <?php endif; ?></td>
                            <td> <span class="blog-card-cont-category"> <?php echo e($post_list->blog_category->blog_cat); ?> </span></td>
                            <td><?php if(!empty ($post_list->blog_author) ): ?> <?php echo e($post_list->blog_author); ?> <?php endif; ?></td>
                            <td><?php if(!empty ($post_list->created_at) ): ?> <?php echo e($post_list->updated_at); ?> <?php endif; ?></td>



                            <td>
                                <div class="button-group">
                                   <a href="<?php echo e(route('admin.blog-post.edit', $post_list->id)); ?>" class="btn btn-secondary"><i class="fi fi-rr-edit"></i></a>
                                   <form action="<?php echo e(route('admin.blog-post.destroy', $post_list->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" name="submit" value="" class="btn btn-danger"><i class="fi fi-rr-trash"></i></button>
                                    </form>
                                </div>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/dashboard/blog/blog-list/blog-all.blade.php ENDPATH**/ ?>