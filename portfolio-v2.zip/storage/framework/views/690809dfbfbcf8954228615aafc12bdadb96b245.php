<section class="testimonial-area">
    <div class="container-fluid">
      <div class="row align-items-center">
        <div class="col-lg-12 col-xl-4 col-12">
          <div class="testimonial-content">
                <?php if(!empty ($testimonial_title->testimonial_settings_title)): ?>
                    <span class="testimonial-cont-sm-title"><?php echo e($testimonial_title->testimonial_settings_section_title); ?></span>
                <?php endif; ?>

                <?php if(empty ($testimonial_title->testimonial_settings_title)): ?>
                    <span class="testimonial-cont-sm-title">Section Title</span>
                <?php endif; ?>

                <?php if(!empty ($testimonial_title->testimonial_settings_title)): ?>
                    <h2 class="testimonial-cont-big-title">
                        <?php echo e($testimonial_title->testimonial_settings_title); ?>

                    </h2>
                <?php endif; ?>

                <?php if(empty ($testimonial_title->testimonial_settings_title)): ?>
                    <h2 class="testimonial-cont-big-title">
                        Enter text here
                    </h2>
                <?php endif; ?>

                <?php if(!empty ($testimonial_title->testimonial_settings_desc)): ?>
                    <p class="testimonial-cont-text">
                        <?php echo strip_tags($testimonial_title->testimonial_settings_desc); ?>
                    </p>
                <?php endif; ?>

                <?php if(empty ($testimonial_title->testimonial_settings_desc)): ?>
                    <p class="testimonial-cont-text">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Molestias asperiores facilis adipisci, ullam eaque nobis.
                        Nesciunt quisquam culpa fuga ullam omnis repellendus aperiam
                        atque dolore quaerat esse! Possimus, cumque dignissimos.
                    </p>
                <?php endif; ?>
          </div>
        </div>
        <div class="col-lg-12 col-xl-7 offset-xl-1 col-12">
          <div class="testimonial-slider-inner">
            <?php if(empty ($testimonial_infolist)): ?>
                <div class="testimonial-slider-single">
                <div class="row align-items-end">
                  <div class="col-lg-6 col-md-6 col-12">
                    <div class="testi-slider-single-left">
                      <img
                        class="testi-quote-icon-1"
                        src="img/testimonial-img/quote-icon-1.svg"
                        alt="#"
                      />
                      <div class="testimonial-slider-img">
                        <img src="img/testimonial-img/img-1.png" alt="#" />
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6 col-md-6 col-12">
                    <div class="testimonial-slider-content">
                      <p class="testimonial-slider-cont-text">
                        Ante facilisi ipsum sit eget dolor maecenas sed.
                        Fringilla laoreet tincidunt nec nulla ullamcorper.
                        Convallis viverra risus, facilisis erat gravida justo,
                        urna ultrices.
                      </p>
                      <div class="testimonial-slider-cont-bottom">
                        <h4 class="testimonial-client-name">Kyle Merwin</h4>
                        <span class="testimonial-client-tag"
                          >CO-owner at LionEnergy</span
                        >
                      </div>
                      <img
                        class="testi-quote-icon-2"
                        src="img/testimonial-img/quote-icon-2.svg"
                        alt="#"
                      />
                    </div>
                  </div>
                </div>
                </div>
            <?php endif; ?>

            <?php if(!empty ($testimonial_infolist)): ?>

                <?php $__currentLoopData = $testimonial_infolist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="testimonial-slider-single">
                        <div class="row align-items-end">
                            <div class="col-lg-6 col-md-6 col-12">
                            <div class="testi-slider-single-left">
                                <img
                                class="testi-quote-icon-1"
                                src="img/testimonial-img/quote-icon-1.svg"
                                alt="#"
                                />
                                <div class="testimonial-slider-img">
                                    <?php if(!empty ($list->testimonial_list_image)): ?>
                                        <img src="<?php echo e($list->testimonial_list_image); ?>" alt="#" />
                                    <?php endif; ?>

                                    <?php if(empty ($list->testimonial_list_image)): ?>
                                        <img src="img/testimonial-img/img-1.png" alt="#" />
                                    <?php endif; ?>
                                </div>
                            </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-12">
                            <div class="testimonial-slider-content">
                                    <?php if(!empty ($list->testimonial_list_comment)): ?>
                                        <p class="testimonial-slider-cont-text">
                                            <?php echo strip_tags($list->testimonial_list_comment); ?>
                                        </p>
                                    <?php endif; ?>

                                    <?php if(empty ($list->testimonial_list_comment)): ?>
                                        <p class="testimonial-slider-cont-text">
                                            Lorem ipsum dolor sit, amet consectetur adipisicing elit.
                                            Natus eveniet commodi, repudiandae doloribus assumenda maiores,
                                            vitae cumque vero incidunt libero enim in.
                                            Obcaecati dicta molestiae ullam culpa suscipit nisi itaque.
                                        </p>
                                    <?php endif; ?>
                                <div class="testimonial-slider-cont-bottom">
                                    <?php if(!empty ($list->testimonial_list_name)): ?>
                                        <h4 class="testimonial-client-name"><?php echo e($list->testimonial_list_name); ?></h4>
                                    <?php endif; ?>

                                    <?php if(empty ($list->testimonial_list_name)): ?>
                                        <h4 class="testimonial-client-name">Kyle Merwin</h4>
                                    <?php endif; ?>

                                    <?php if(!empty ($list->testimonial_list_info)): ?>
                                        <span class="testimonial-client-tag"><?php echo e($list->testimonial_list_info); ?></span>
                                    <?php endif; ?>

                                    <?php if(empty ($list->testimonial_list_info)): ?>
                                        <span class="testimonial-client-tag">CO-owner at LionEnergy</span>
                                    <?php endif; ?>

                                </div>
                                <img
                                class="testi-quote-icon-2"
                                src="img/testimonial-img/quote-icon-2.svg"
                                alt="#"
                                />
                            </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

          </div>
        </div>
      </div>
    </div>
  </section>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/testimonial.blade.php ENDPATH**/ ?>