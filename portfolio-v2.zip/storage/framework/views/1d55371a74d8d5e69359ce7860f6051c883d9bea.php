<section class="hero-area">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12">

          <div class="hero-content">
            <div class="hero-content-top">
            <?php if(!empty ($banner_settings->hero_title)): ?>
              <h1
                class="hero-content-title wow fadeInUp"
                data-wow-delay="0.1s"
              >
                <?php echo e($banner_settings->hero_title); ?>

            </h1>
			<?php endif; ?>

            <?php if(empty ($banner_settings->hero_title)): ?>
              <h1
                class="hero-content-title wow fadeInUp"
                data-wow-delay="0.1s"
              >
              Entrepreneur with big dreams.
            </h1>
			<?php endif; ?>

              <div
                class="hero-content-btn wow fadeInUp"
                data-wow-delay="0.1s"
              >
            <?php if(!empty ($banner_settings->hero_button_text)): ?>
                <a href="<?php echo e($banner_settings->hero_button_url); ?>" target="_blank" class="theme-btn"
                  ><?php echo e($banner_settings->hero_button_text); ?><i class="fi-rr-arrow-right"></i
                  ><i class="fi-rr-arrow-right"></i
                ></a>
			<?php endif; ?>

            <?php if(empty ($banner_settings->hero_button_text)): ?>
                <a href="#contact" class="theme-btn"
                  >Get consultation<i class="fi-rr-arrow-right"></i
                  ><i class="fi-rr-arrow-right"></i
                ></a>
			<?php endif; ?>

              </div>
              <div class="hero-content-bottom">
                <ul class="hero-content-list">
                    <?php if(!empty ($banner_settings->hero_tag_one)): ?>
                        <li><?php echo e($banner_settings->hero_tag_one); ?></li>
                    <?php endif; ?>
                    <?php if(empty ($banner_settings->hero_tag_one)): ?>
                        <li>Enthusiastic</li>
                    <?php endif; ?>
                    <?php if(!empty ($banner_settings->hero_tag_two)): ?>
                        <li><?php echo e($banner_settings->hero_tag_two); ?></li>
                    <?php endif; ?>
                    <?php if(empty ($banner_settings->hero_tag_two)): ?>
                        <li>Creative</li>
                    <?php endif; ?>
                    <?php if(!empty ($banner_settings->hero_tag_three)): ?>
                        <li><?php echo e($banner_settings->hero_tag_three); ?></li>
                    <?php endif; ?>
                    <?php if(empty ($banner_settings->hero_tag_three)): ?>
                        <li>Aesthetic</li>
                    <?php endif; ?>
                </ul>
                <div class="hero-scroll-down-btn">
                  <a href="#about" class="scroll-down"></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- <div
      class="hero-btm-shape"
      style="background-image: url('img/hero-bottom-shape.svg')"
    ></div> -->
  </section>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/hero.blade.php ENDPATH**/ ?>