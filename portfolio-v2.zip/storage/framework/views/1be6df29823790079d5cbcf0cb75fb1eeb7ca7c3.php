<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger" role="alert">
        <button type="button" class="btn-close" aria-label="Close"></button>
        <strong>Error!</strong><?php echo e($error); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <button type="button" class="btn-close" aria-label="Close"></button>
        <strong>Error!</strong><?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <button type="button" class="btn-close" aria-label="Close"></button>
        <strong>success!</strong><?php echo e(session('success')); ?>

    </div>
<?php endif; ?><?php /**PATH H:\GetUp\project\portfolio\resources\views/alert/messages.blade.php ENDPATH**/ ?>