
<section id="home" class="hero-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="hero-inner">
                    <div class="row">
                        <div class="col-12">
                            <div class="hero-slider">

                                <?php if(empty ($sliders_list)): ?>
                                <!-- Single Slider -->
                                <div class="hero-single-slider">
                                    <div class="row">
                                        <div class="col-lg-12 col-xl-6 col-12">
                                            <div class="hero-content">
                                                <span class="hero-sm-title"><img src="./img/text-shape.svg" alt="#" />Welcome
                                                    to My Website</span>
                                                <h1 class="hero-big-title">
                                                    Building a Thriving Business from the Ground Up
                                                </h1>
                                                <div class="hero-btn">
                                                    <a href="#" class="theme-btn">Get a free consultation<i class="fi-rr-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-xl-6 col-12 order-class">
                                            <div class="hero-img">
                                                <img src="./img/hero-images/img-1.png" alt="#" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single Slider -->
                                <?php endif; ?>

                                <?php if(!empty ($sliders_list)): ?>

                                <?php $__currentLoopData = $sliders_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Single Slider -->
                                <div class="hero-single-slider">
                                    <div class="row">
                                        <div class="col-lg-12 col-xl-6 col-12">
                                            <div class="hero-content">
                                                <span class="hero-sm-title"><img src="./img/text-shape.svg" alt="#" /><?php echo e($list->hero_sub_title); ?></span>
                                                <h1 class="hero-big-title">
                                                    <?php echo e($list->hero_title); ?>

                                                </h1>
                                                <div class="hero-btn">
                                                    <a href="<?php echo e($list->hero_button_url); ?>" class="theme-btn"><?php echo e($list->hero_button_text); ?><i class="fi-rr-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-xl-6 col-12 order-class">
                                            <div class="hero-img">
                                                <img src="<?php echo e($list->hero_img); ?>" alt="#" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single Slider -->

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <!-- Hero Social Icons -->
                            <div class="hero-social">
                                <span class="hero-social-title">Follow me</span>
                                <ul class="hero-social-list">
                                    <li>
                                        <a href="#" target="_blank"><img src="./img/icons/facebook.svg" alt="#" /></a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank"><img src="./img/icons/linkedin.svg" alt="#" /></a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank"><img src="./img/icons/twitter.svg" alt="#" /></a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank"><img src="./img/icons/instagram.svg" alt="#" /></a>
                                    </li>
                                </ul>
                            </div>
                            <!-- Scroll Down Button -->
                            <div class="hero-scroll-down-btn">
                                <a href="#about" class="scroll-down"></a>
                            </div>
                            <!-- Hero Characteristic -->
                            <div class="hero-characteristic">
                                <div class="hero-characteristic-list">

                                    <?php if(!empty ($banner_settings->hero_tag_one)): ?>
                                    <span><?php echo e($banner_settings->hero_tag_one); ?></span>
                                    <?php endif; ?>
                                    <?php if(empty ($banner_settings->hero_tag_one)): ?>
                                    <span>Enthusiastic</span>
                                    <?php endif; ?>
                                    <?php if(!empty ($banner_settings->hero_tag_two)): ?>
                                    <span><?php echo e($banner_settings->hero_tag_two); ?></span>
                                    <?php endif; ?>
                                    <?php if(empty ($banner_settings->hero_tag_two)): ?>
                                    <span>Creative</span>
                                    <?php endif; ?>
                                    <?php if(!empty ($banner_settings->hero_tag_three)): ?>
                                    <span><?php echo e($banner_settings->hero_tag_three); ?></span>
                                    <?php endif; ?>
                                    <?php if(empty ($banner_settings->hero_tag_three)): ?>
                                    <span>Aesthetic</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH H:\GetUp\project\portfolio-v2\resources\views/pages/frontend/sections/hero.blade.php ENDPATH**/ ?>