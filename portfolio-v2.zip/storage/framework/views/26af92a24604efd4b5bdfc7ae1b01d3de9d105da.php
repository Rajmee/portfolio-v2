<section class="photography-area">
    <div class="container-fluid">
      <div class="row">
        <div class="photography-section-head">
            <?php if(!empty ($image_title->section_title)): ?>
                <h3 class="photography-sec-head-title">[<?php echo e($image_title->section_title); ?>]</h3>
            <?php endif; ?>

            <?php if(empty ($image_title->section_title)): ?>
                <h3 class="photography-sec-head-title">[Enter Section Title]</h3>
            <?php endif; ?>

        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="photography-gallery-inner">
            <div class="row g-0">
              <div class="col-lg-12 col-xl-12 col-12">
                <div class="row g-0">

                    <?php $__currentLoopData = $image_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(!empty ($img->image)): ?>
                            <div class="col-lg-3 col-md-4 col-12">
                                <div class="photography-gallery-single">
                                <div class="gallery-single-img img-9">
                                    <a
                                    href="<?php echo e($img->image); ?>"
                                    data-fancybox="photo"
                                    class="image-view"
                                    ><img src="<?php echo e($img->image); ?>" alt="#"
                                    /></a>
                                </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(empty ($img->image)): ?>
                            <div class="col-lg-3 col-md-4 col-12">
                                <div class="photography-gallery-single">
                                <div class="gallery-single-img img-9">
                                    <a
                                    href="img/photography/img-9.jpg"
                                    data-fancybox="photo"
                                    class="image-view"
                                    ><img src="img/photography/img-9.jpg" alt="#"
                                    /></a>
                                </div>
                                </div>
                            </div>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
      </div>
    </div>
  </section>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/gallery.blade.php ENDPATH**/ ?>