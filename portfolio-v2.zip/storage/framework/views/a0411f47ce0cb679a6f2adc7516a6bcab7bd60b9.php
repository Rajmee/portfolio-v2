<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">All Categories</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.home')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.blog-cat.all')); ?>">All Categories</a>
            </li>
        </ul>
    </div>



  <div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="add-row" class="display table table-striped table-hover" >
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($blog_cat_list)>0): ?>
                        <?php $__currentLoopData = $blog_cat_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php if(!empty ($cat_list->blog_cat) ): ?> <?php echo e($cat_list->blog_cat); ?> <?php endif; ?></td>

                            <td>
                                <div class="button-group">
                                   <a href="<?php echo e(route('admin.blog-cat.edit', $cat_list->id)); ?>" class="btn btn-secondary"><i class="fi fi-rr-edit"></i></a>
                                   <form action="<?php echo e(route('admin.blog-cat.destroy', $cat_list->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" name="submit" value="" class="btn btn-danger"><i class="fi fi-rr-trash"></i></button>
                                    </form>
                                </div>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/dashboard/blog/blog-cat/blog-cat-all.blade.php ENDPATH**/ ?>