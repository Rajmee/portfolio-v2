<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">All Achievement</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.home')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item" style="width: 700px;">
                <a href="<?php echo e(route('admin.achievement-info.all')); ?>">All Achievement</a>
            </li>

        </ul>
    </div>



  <div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="add-row" class="display table table-striped table-hover" >
                    <thead>
                        <tr>
                            <th>Achievement Image</th>
                            <th>Achievement Title</th>
                            <th>Achievement Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($achievement_info_lists)>0): ?>
                        <?php $__currentLoopData = $achievement_info_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php if(!empty ($info_list->org_img) ): ?> <div class="avatar"><img  class="avatar-img" src="<?php echo e(url($info_list->org_img)); ?>"></div><?php endif; ?></td>
                            <td><?php if(!empty ($info_list->org_title) ): ?> <?php echo e($info_list->org_title); ?> <?php endif; ?></td>
                            <td><?php if(!empty ($info_list->org_date) ): ?> <?php echo e($info_list->org_date); ?> <?php endif; ?></td>

                            <td>
                                <div class="button-group">
                                   <a href="<?php echo e(route('admin.achievement-info.edit', $info_list->id)); ?>" class="btn btn-secondary"><i class="fi fi-rr-edit"></i></a>
                                   <form action="<?php echo e(route('admin.achievement-info.destroy', $info_list->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" name="submit" value="" class="btn btn-danger"><i class="fi fi-rr-trash"></i></button>
                                    </form>
                                </div>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\GetUp\project\portfolio-v2\resources\views/pages/dashboard/achievement/achievement-all.blade.php ENDPATH**/ ?>