<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


	<link rel="stylesheet" href="<?php echo e(asset('assets/css/boxicons.css')); ?>">
	<link class="template-customizer-core-css" rel="stylesheet" href="<?php echo e(asset('assets/css/core.css')); ?>">
	<link class="template-customizer-theme-css" rel="stylesheet" href="<?php echo e(asset('assets/css/theme-default.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/page-auth.css')); ?>">







</head>
<body>
    <div id="app">
        

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="<?php echo e(asset('assets/js/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/core/jquery.3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/helpers.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

</body>
</html>
<?php /**PATH H:\GetUp\project\portfolio-v2\resources\views/layouts/app.blade.php ENDPATH**/ ?>