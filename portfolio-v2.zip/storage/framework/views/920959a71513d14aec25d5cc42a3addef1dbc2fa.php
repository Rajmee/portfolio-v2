<section class="experience-area">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12">
          <div class="experience-section-head">
            <?php if(!empty ($expertise_title->expertise_section_title)): ?>
                <h2 class="exp-section-head-title">[<?php echo e($expertise_title->expertise_section_title); ?>]</h2>
            <?php endif; ?>

            <?php if(empty ($expertise_title->expertise_section_title)): ?>
                <h2 class="exp-section-head-title">[Enter Section Title]</h2>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <div class="row">
        <?php $counter = 1 ?>
		<?php $__currentLoopData = $expertise_infolist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($counter % 2 != 0): ?>
            <div
            class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
            data-wow-delay="<?'.'.$counter.'s'?>"
            >
            <div class="experience-single-card">
                <div class="exp-card-icon">
                <img src="<?php echo e($list->expertise_info_icon); ?>" alt="#" />
                </div>
                <div class="exp-card-content">
                <span class="exp-card-number"><?php echo '0' . $counter?></span>
                <h4 class="exp-card-content-title"><?php echo e($list->expertise_info_title); ?></h4>
                <p class="exp-card-content-text">
                    
                    <?php echo strip_tags($list->expertise_info_desc); ?>

                </p>
                </div>
            </div>
            </div>
        <?php endif; ?>

        <?php if($counter % 2 == 0): ?>
            <div
            class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
            data-wow-delay="<?'.'.$counter.'s'?>"

            
            >
            <div class="experience-single-card add-margin">
                <div class="exp-card-icon">
                <img src="<?php echo e($list->expertise_info_icon); ?>" alt="#" />
                </div>
                <div class="exp-card-content">
                <span class="exp-card-number"><?php echo '0' . $counter?></span>
                <h4 class="exp-card-content-title"><?php echo e($list->expertise_info_title); ?></h4>
                <p class="exp-card-content-text">
                    <?php echo strip_tags($list->expertise_info_desc); ?>
                </p>
                </div>
            </div>
            </div>
        <?php endif; ?>
        <?php $counter++?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
    </div>
  </section>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/expertise.blade.php ENDPATH**/ ?>