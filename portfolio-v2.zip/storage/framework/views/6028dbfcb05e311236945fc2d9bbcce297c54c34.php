    <footer class="footer-area">
      <div class="container-fluid">
        <div class="col-lg-8 offset-lg-2 col-md-8 offset-md-2 col-12">
          <div class="footer-content">

                <?php if(!empty ($footer_settings->name)): ?>
                    <p class="footer-copyright-text">
                        Copyright © <?php echo date("Y"); ?>. <a href="<?php echo e($footer_settings->url); ?>" target="#"><?php echo e($footer_settings->name); ?></a>
                        All right reserved. Developed by
                        <a href="https://getup.com.bd/" target="_blank">GetUp Ltd.</a>
                    </p>
                <?php endif; ?>

                <?php if(empty ($footer_settings->name)): ?>
                    <p class="footer-copyright-text">
                        Copyright © <?php echo date("Y"); ?>. <a href="#" target="#">Your name</a>
                        All right reserved. Developed by
                        <a href="https://getup.com.bd/" target="_blank">GetUp Ltd.</a>
                    </p>
                <?php endif; ?>

            
              
            
          </div>
        </div>
      </div>
    </footer>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/layouts/frontend/footer.blade.php ENDPATH**/ ?>