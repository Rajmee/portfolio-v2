<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php if(!empty ($site_settings->meta_key)): ?>
        <meta name="keywords" content="<?php echo e($site_settings->meta_key); ?>">
    <?php endif; ?>

    <?php if(empty ($site_settings->meta_key)): ?>
        <meta name="keywords" content="">
    <?php endif; ?>


    <?php if(!empty ($site_settings->meta_desc)): ?>
        <meta name="description" content="<?php echo e($site_settings->meta_desc); ?>">
    <?php endif; ?>

    <?php if(empty ($site_settings->meta_desc)): ?>
        <meta name="description" content="">
    <?php endif; ?>


    <?php if(!empty ($site_settings->meta_author)): ?>
	    <meta name="author" content="<?php echo e($site_settings->meta_author); ?>">
    <?php endif; ?>

    <?php if(empty ($site_settings->meta_author)): ?>
        <meta name="description" content="">
    <?php endif; ?>


	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php if(!empty ($site_settings->site_title)): ?>
        <title><?php echo e($site_settings->site_title); ?></title>
    <?php endif; ?>

    <?php if(empty ($site_settings->site_title)): ?>
        <title>Portfolio Website</title>
    <?php endif; ?>

    <?php if(!empty ($site_settings->site_favicon)): ?>
        <link rel="icon" href="<?php echo $site_settings->site_favicon ?>" />
    <?php endif; ?>

    <?php if(empty ($site_settings->site_favicon)): ?>
        <link rel="icon" href="" />
    <?php endif; ?>
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;0,900;1,400&display=swap" rel="stylesheet">



    <!-- Bootstrap -->


	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
	<!-- Animate CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
	<!-- Owl Carousel CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
	<!-- AOS CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
    <!-- Maginific Popup -->
	<link rel="stylesheet" href="<?php echo e(asset('css/maginific-popup.min.css')); ?>">
    <!-- Nice Popup -->
	<link rel="stylesheet" href="<?php echo e(asset('css/nice-select.min.css')); ?>">
    <!-- Datepicker Popup -->
	<link rel="stylesheet" href="<?php echo e(asset('css/datepicker.css')); ?>">
    <!-- Fancybox Popup -->
	<link rel="stylesheet" href="<?php echo e(asset('css/fancybox.css')); ?>">
	<!-- Back To Top CSS Portfolio -->
	<link rel="stylesheet" href="<?php echo e(asset('css/backToTop.css')); ?>">
	<!-- Uicons -->
	<link rel="stylesheet" href="<?php echo e(asset('css/uicons.css')); ?>">
    <!-- Icofont -->
	<link rel="stylesheet" href="<?php echo e(asset('css/icofont.css')); ?>">
	<!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.min.css')); ?>">
</head>
<body>

    <?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('alert.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Jquery JS -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-migrate.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- Modernizer JS -->
<script src="<?php echo e(asset('js/modernizer.min.js')); ?>"></script>
<!-- Maginific Popup JS -->
<script src="<?php echo e(asset('js/magnific-popup.min.js')); ?>"></script>
<!-- Owl Carousel JS -->
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
<!-- Slick Slider JS -->
<script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
<!-- FancyBox JS -->
<script src="<?php echo e(asset('js/jquery-fancybox.min.js')); ?>"></script>
<!-- CounterUp JS -->
<script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
<!-- Nice Select JS -->
<script src="<?php echo e(asset('js/nice-select.min.js')); ?>"></script>
<!-- Datepicker JS -->
<script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
<!-- Back To Top JS -->
<script src="<?php echo e(asset('js/backToTop.js')); ?>"></script>
<!-- Wow JS -->
<script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
<!-- Wow JS -->
<script src="<?php echo e(asset('js/ajax-mail.js')); ?>"></script>
<!-- Main JS -->
<script src="<?php echo e(asset('js/active.js')); ?>"></script>
</body>
</html>

<?php /**PATH H:\GetUp\project\portfolio\resources\views/layouts/frontend/app.blade.php ENDPATH**/ ?>