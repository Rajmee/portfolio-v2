<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <h4 class="page-title">All Message</h4>
        <ul class="breadcrumbs">
            <li class="nav-home">
                <a href="<?php echo e(route('admin.home')); ?>">
                    <i class="flaticon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="flaticon-right-arrow"></i>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('admin.message-type.all')); ?>">All Type</a>
            </li>
        </ul>
    </div>



  <div class="col-md-12">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table id="add-row" class="display table table-striped table-hover" >
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Topic type</th>
                            <th>Appointment Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($message_list)>0): ?>
                        <?php $__currentLoopData = $message_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php if(!empty ($list->name) ): ?> <?php echo e($list->name); ?> <?php endif; ?></td>
                            <td><?php if(!empty ($list->email) ): ?> <?php echo e($list->email); ?> <?php endif; ?></td>
                            <td><?php if(!empty ($list->message_type->topic) ): ?> <?php echo e($list->message_type->topic); ?> <?php endif; ?></td>
                            
                            <td><?php if(!empty ($list->appoint_date) ): ?> <?php echo e($list->appoint_date); ?> <?php endif; ?></td>

                            <td>
                                <div class="button-group">
                                    <a href="<?php echo e(route('admin.message.view', $list->id)); ?>" class="btn btn-secondary"><i class="fi fi-rr-eye"></i></a>
                                    
                                </div>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\GetUp\project\portfolio-v2\resources\views/pages/dashboard/message/message-all/message-all.blade.php ENDPATH**/ ?>