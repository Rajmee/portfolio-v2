<?php $__env->startSection('content'); ?>

<div class="page-header">
    <h4 class="page-title">Sliders</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="<?php echo e(route('admin.home')); ?>">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.sliders.all')); ?>">Sliders</a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('admin.sliders.edit', $hero_slider->id)); ?>">Edit Slider</a>
        </li>
    </ul>
</div>

<div class="card">
    <div class="card-header">
        <div class="card-title">Edit Slider</div>
    </div>
    <form action="<?php echo e(route('admin.sliders.update', $hero_slider->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="medialist_title">Sliders Title</label>
                        <input type="text" class="form-control" id="hero_title" name="hero_title" placeholder="Type title" value="<?php echo e($hero_slider->hero_title); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="medialist_title">Sliders Sub Title</label>
                        <input type="text" class="form-control" id="hero_sub_title" name="hero_sub_title" placeholder="Type sub title" value="<?php echo e($hero_slider->hero_sub_title); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="header_button">Slider Button Text</label>
                        <input type="text" class="form-control" id="hero_button_text" name="hero_button_text" placeholder="Type button text" value="<?php echo e($hero_slider->hero_button_text); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="header_button_url">Hero Button URL</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="basic-addon3">https://youtsite.com/path_url</span>
                            </div>
                            <input type="text" class="form-control" id="hero_button_url" name="hero_button_url" placeholder="Type button url" value="<?php echo e($hero_slider->hero_button_url); ?>" required>
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="medialist_thumbnail mb-6">
                            <figure class="imagecheck-figure">
                                <img src="<?php echo e(url($hero_slider->hero_img)); ?>" alt="title" class="imagecheck-image">
                            </figure>
                            
                            
                            <div class="input-group">
                                <span class="input-group-btn">
                                    <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary text-white">
                                        <i class="fi fi-rr-picture"></i> Set hero image
                                    </a>
                                </span>
                                <input id="thumbnail" class="form-control" type="text" name="hero_img" value="<?php echo e($hero_slider->hero_img); ?>">
                            </div>
                            <small id="emailHelp" class="form-text text-muted">Please upload jpg, jpeg, png file.</small>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-action">
            <button class="btn btn-success" type="submit" name="submit">Update</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#expertise_info_desc'))
        .catch(error => {
            console.error(error);
        });

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\GetUp\project\portfolio-v2\resources\views/pages/dashboard/herosliders/slider-edit.blade.php ENDPATH**/ ?>