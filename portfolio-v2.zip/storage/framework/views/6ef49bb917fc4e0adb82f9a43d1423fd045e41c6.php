<section class="blog-area blog-section">
    <div class="container-fluid">
      <div class="row">
            <?php if(!empty ($blog_section_settings->blog_section_title)): ?>
                <div class="blog-section-head">
                    <h3 class="blog-sec-head-title">[<?php echo e($blog_section_settings->blog_section_title); ?>]</h3>
                </div>
            <?php endif; ?>

            <?php if(empty ($blog_section_settings->blog_section_title)): ?>
                <div class="blog-section-head">
                    <h3 class="blog-sec-head-title">[Enter text here]</h3>
                </div>
            <?php endif; ?>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="blog-slider">

        <?php $counter = 1 ?>
		<?php $__currentLoopData = $blog_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($counter % 2 != 0): ?>

            <div class="blog-single-card card-1">
              <div class="blog-card-img">
                <img src="<?php echo e($list->blog_img); ?>" alt="#" />
              </div>
              <div class="blog-card-content">
                <span class="blog-card-cont-category"><?php echo e($list->blog_category->blog_cat); ?> </span>
                <h3 class="blog-card-cont-title">
                    <?php echo e($list->blog_title); ?>

                </h3>
                <div class="blog-card-cont-btn">
                  <a href="<?php echo e(route('user.blog-post.view', [$list->slug, $list->id])); ?>" class="blog-card-btn"
                    >Read more<i class="fi-rr-arrow-right"></i
                  ></a>
                </div>
              </div>
            </div>

        <?php endif; ?>

        <?php if($counter % 2 == 0): ?>

            <div class="blog-single-card card-2">
              <div class="blog-card-img">
                <img src="<?php echo e($list->blog_img); ?>" alt="#" />
              </div>
              <div class="blog-card-content">
                <span class="blog-card-cont-category"><?php echo e($list->blog_category->blog_cat); ?></span>
                <h3 class="blog-card-cont-title">
                    <?php echo e($list->blog_title); ?>

                </h3>
                <div class="blog-card-cont-btn">
                  <a href="<?php echo e(route('user.blog-post.view', [$list->slug, $list->id])); ?>" class="blog-card-btn"
                    >Read more<i class="fi-rr-arrow-right"></i
                  ></a>
                </div>
              </div>
            </div>

        <?php endif; ?>
        <?php $counter++?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
      </div>
    </div>
  </section>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/blog.blade.php ENDPATH**/ ?>