<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h4 class="page-title">Blog Categories</h4>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="#">
                <i class="flaticon-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="flaticon-right-arrow"></i>
        </li>
        <li class="nav-item">
            
            <a href="#">Blog</a>
        </li>
    </ul>
 </div>


 <div class="card">
    <form action="<?php echo e(route('admin.blog-cat.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card-body">
           <div class="row">
                <div class="col-lg-6">
                    <div class="form-group">
                        <label for="medialist_title">Blog Category</label>
                        <input type="text" class="form-control" id="blog_cat" name="blog_cat" placeholder="Type blog category" required>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-action">
            <button class="btn btn-success" type="submit" name="submit">Save</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\GetUp\project\portfolio-v2\resources\views/pages/dashboard/blog/blog-cat/blog-cat-add.blade.php ENDPATH**/ ?>