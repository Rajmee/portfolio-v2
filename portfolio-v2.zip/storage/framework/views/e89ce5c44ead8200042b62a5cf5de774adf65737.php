<section id="about" class="about-me-area">
    <div class="about-me-img">
        <?php if(!empty ($about_settings->about_image)): ?>
            <img src="<?php echo e($about_settings->about_image); ?>" alt="#" />
        <?php endif; ?>

        <?php if(empty ($about_settings->about_image)): ?>
            <img src="img/about-img.jpg" alt="#" />
        <?php endif; ?>

    </div>
    <div class="container-fluid">
      <div class="row g-0">
        <div class="col-lg-12 col-xl-5 offset-xl-6 col-12">
          <div class="about-me-content">
            <h3 class="aboutme-cont-sm-title">
              Grettings!<br />
                <?php if(!empty ($about_settings->about_name)): ?>
                    I’m <span> <?php echo e($about_settings->about_name); ?></span>
                <?php endif; ?>

                <?php if(empty ($about_settings->about_name)): ?>
                    I’m <span> 'Your name' </span>
                <?php endif; ?>

            </h3>
            <div class="aboutme-cont-main">
              <img src="img/quote-icon.svg" alt="#" />
                <?php if(!empty ($about_settings->about_quote)): ?>
                    <h1 class="aboutme-cont-big-title">
                        <?php echo e($about_settings->about_quote); ?>

                    </h1>
                <?php endif; ?>

                <?php if(empty ($about_settings->about_quote)): ?>
                    <h1 class="aboutme-cont-big-title">
                        'Your Quotes will be here'
                    </h1>
                <?php endif; ?>

                <?php if(!empty ($about_settings->about_description)): ?>
                    <p class="aboutme-cont-text">
                        <?php echo strip_tags($about_settings->about_description); ?>
                    </p>
                <?php endif; ?>

                <?php if(empty ($about_settings->about_description)): ?>
                    <p class="aboutme-cont-text">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Etiam dapibus est a nibh vestibulum, sed suscipit velit lobortis.
                        Mauris vehicula hendrerit enim quis mollis.
                        Interdum et malesuada fames ac ante ipsum primis in faucibus.
                    </p>
                <?php endif; ?>
              
                <?php if(!empty ($about_settings->about_qus)): ?>
                    <h4 class="aboutme-cont-btm-title">
                        <?php echo e($about_settings->about_qus); ?>

                    </h4>
                <?php endif; ?>

                <?php if(empty ($about_settings->about_qus)): ?>
                    <h4 class="aboutme-cont-btm-title">
                        'Your question will be here?'
                    </h4>
                <?php endif; ?>

                <?php if(!empty ($about_settings->about_button_text)): ?>
                    <div class="aboutme-cont-btn">
                            <a href="<?php echo e($about_settings->about_button_url); ?>" target="_blank" class="theme-btn"
                            ><?php echo e($about_settings->about_button_text); ?><i class="fi-rr-arrow-right"></i
                            ><i class="fi-rr-arrow-right"></i
                            ></a>
                    </div>
                <?php endif; ?>

                <?php if(empty ($about_settings->about_button_text)): ?>
                    <div class="aboutme-cont-btn">
                            <a href="#" class="theme-btn">
                                Enter Button text
                                <i class="fi-rr-arrow-right"></i><i class="fi-rr-arrow-right"></i
                            ></a>
                    </div>
                <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php $__env->startSection('scripts'); ?>
	<script>
        const div = document.querySelector('.aboutme-cont-text');
	</script>
<?php $__env->stopSection(); ?>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/about.blade.php ENDPATH**/ ?>