<!-- preloader  -->
<div id="preloader">
    <div id="ctn-preloader" class="ctn-preloader">
      <div class="animation-preloader">
        <div class="spinner"></div>
      </div>
      <div class="loader">
        <div class="row">
          <div class="col-3 loader-section section-left">
            <div class="bg"></div>
          </div>
          <div class="col-3 loader-section section-left">
            <div class="bg"></div>
          </div>
          <div class="col-3 loader-section section-right">
            <div class="bg"></div>
          </div>
          <div class="col-3 loader-section section-right">
            <div class="bg"></div>
          </div>
        </div>
      </div>
    </div>
</div>
<!-- preloader end -->

<!-- back to top start -->
<div class="progress-wrap">
    <svg
      class="progress-circle svg-content"
      width="100%"
      height="100%"
      viewBox="-1 -1 102 102"
    >
      <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
    </svg>
</div>
<!-- back to top end -->



<div class="follow-me-fixed">
  <ul class="follow-me-social">
    <li>
        <?php if(!empty ($header_social_settings->facebook)): ?>
            <a href="<?php echo e($header_social_settings->facebook); ?>" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/facebook.svg')); ?>"
            /></a>
        <?php endif; ?>

        <?php if(empty ($header_social_settings->facebook)): ?>
            <a href="#" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/facebook.svg')); ?>"
            /></a>
        <?php endif; ?>

    </li>
    <li>
        <?php if(!empty ($header_social_settings->linkedin)): ?>
            <a href="<?php echo e($header_social_settings->linkedin); ?>" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/linkedin.svg')); ?>"
            /></a>
        <?php endif; ?>

        <?php if(empty ($header_social_settings->linkedin)): ?>
            <a href="#" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/linkedin.svg')); ?>"
            /></a>
        <?php endif; ?>
    </li>
    <li>
        <?php if(!empty ($header_social_settings->twitter)): ?>
            <a href="<?php echo e($header_social_settings->twitter); ?>" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/twitter.svg')); ?>"
            /></a>
        <?php endif; ?>

        <?php if(empty ($header_social_settings->twitter)): ?>
            <a href="#" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/twitter.svg')); ?>"
            /></a>
        <?php endif; ?>
    </li>
    <li>
        <?php if(!empty ($header_social_settings->instagram)): ?>
            <a href="<?php echo e($header_social_settings->instagram); ?>" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/instagram.svg')); ?>"
            /></a>
        <?php endif; ?>

        <?php if(empty ($header_social_settings->linkedin)): ?>
            <a href="#" target="_blank"
            ><img src="<?php echo e(asset('img/follow-me-social-icon/instagram.svg')); ?>"
            /></a>
        <?php endif; ?>
    </li>

  </ul>
  <p class="follow-me-text">Follow me</p>
</div>

<!-- Header -->
<header class="header">
  <div class="container-fluid">
    <div class="row align-items-center">
      <div class="col-12">
        <div class="navigation">
          <input
            type="checkbox"
            class="navigation__checkbox"
            id="nav-toggle"
          />
          <label for="nav-toggle" class="navigation__button">
            <span
              class="navigation__icon"
              aria-label="toggle navigation menu"
            ></span>
          </label>
          <div class="navigation__background"></div>

          <nav class="navigation__nav" role="navigation">
            <ul class="navigation__list">
              <li class="navigation__item">
                <a href="<?php echo e(route('index')); ?>" class="navigation__link active"
                  >Home</a
                >
              </li>
              <li class="navigation__item">
                <a href="<?php echo e(route('user.blog-post.all')); ?>" class="navigation__link"
                  >Blog/case</a
                >
              </li>
              
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>