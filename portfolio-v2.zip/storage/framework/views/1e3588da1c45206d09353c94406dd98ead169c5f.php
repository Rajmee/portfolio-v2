<section class="business-solution-area">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-8 offset-lg-2 col-xl-8 offset-xl-2 col-12">
          <div class="biz-solution-content">
                <?php if(!empty ($business_title->business_settings_section_title)): ?>
                    <span class="biz-solution-cont-sm-title"><?php echo e($business_title->business_settings_section_title); ?></span>
                <?php endif; ?>

                <?php if(empty ($business_title->business_settings_section_title)): ?>
                    <span class="biz-solution-cont-sm-title">Enter section title</span>
                <?php endif; ?>

                <?php if(!empty ($business_title->business_settings_title)): ?>
                    <h2 class="biz-solution-cont-big-title">
                        <?php echo e($business_title->business_settings_title); ?>

                    </h2>
                <?php endif; ?>

                <?php if(empty ($business_title->business_settings_title)): ?>
                    <h2 class="biz-solution-cont-big-title">
                        Enter Text Here.
                    </h2>
                <?php endif; ?>

                <?php if(!empty ($business_title->business_settings_desc)): ?>
                    <p class="biz-solution-cont-text">
                        <?php echo strip_tags($business_title->business_settings_desc); ?>

                    </p>
                <?php endif; ?>

                <?php if(empty ($business_title->business_settings_desc)): ?>
                    <p class="testimonial-cont-text">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Molestias asperiores facilis adipisci, ullam eaque nobis.
                        Nesciunt quisquam culpa fuga ullam omnis repellendus aperiam
                        atque dolore quaerat esse! Possimus, cumque dignissimos.
                    </p>
                <?php endif; ?>

          </div>
        </div>
      </div>
      <div class="row">

        <?php if(empty ($business_list)): ?>

            <div
            class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
            data-wow-delay="0.1s"
            >
            <div class="biz-solution-card">
                <img src="img/business-solutions-icon/line-icons.svg" alt="#" />
                <div class="biz-solution-card-content">
                <h3 class="biz-solution-card-title">Software Solution</h3>
                <p class="biz-solution-card-tag">
                    Founder & CEO at
                    <a href="https://softifybd.com/" target="_blank"
                    >SoftifyBD Ltd.</a
                    >
                </p>
                <div class="biz-solution-card-btn">
                    <a href="#" class="theme-btn"
                    >Explore now<i class="fi-rr-arrow-right"></i
                    ><i class="fi-rr-arrow-right"></i
                    ></a>
                </div>
                </div>
            </div>
            </div>

        <?php endif; ?>

        <?php if(!empty ($business_list)): ?>

            <?php $__currentLoopData = $business_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div
                class="col-lg-6 col-xl-3 col-md-6 col-12 wow fadeInUp"
                data-wow-delay="0.1s"
                >
                <div class="biz-solution-card">
                    <img src="img/business-solutions-icon/line-icons.svg" alt="#" />
                    <div class="biz-solution-card-content">
                        <?php if(!empty ($list->business_list_title)): ?>
                            <h3 class="biz-solution-card-title"><?php echo e($list->business_list_title); ?></h3>
                        <?php endif; ?>

                        <?php if(empty ($list->business_list_title)): ?>
                            <h3 class="biz-solution-card-title">Software Solution</h3>
                        <?php endif; ?>

                        <?php if(!empty ($list->business_list_pos)): ?>
                            <p class="biz-solution-card-tag"><?php echo e($list->business_list_pos); ?> at
                            <a href="<?php echo e($list->business_list_button_url); ?>" target="_blank"><?php echo e($list->business_list_comp); ?></a>
                        <?php endif; ?>

                        <?php if(empty ($list->business_list_pos)): ?>
                            <p class="biz-solution-card-tag">Founder & CEO at
                            <a href="https://softifybd.com/" target="_blank">SoftifyBD Ltd.</a>
                        <?php endif; ?>

                        <?php if(!empty ($list->business_list_button_text)): ?>
                            <div class="biz-solution-card-btn">
                                <a href="<?php echo e($list->business_list_button_url); ?>" class="theme-btn" target="_blank"><?php echo e($list->business_list_button_text); ?><i class="fi-rr-arrow-right">
                                </i><i class="fi-rr-arrow-right"></i></a>
                            </div>
                        <?php endif; ?>

                        <?php if(empty ($list->business_list_button_text)): ?>
                            <div class="biz-solution-card-btn">
                                <a href="#" class="theme-btn"
                                >Explore now<i class="fi-rr-arrow-right"></i
                                ><i class="fi-rr-arrow-right"></i
                                ></a>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

      </div>
    </div>
  </section>
<?php /**PATH H:\GetUp\project\portfolio\resources\views/pages/frontend/sections/business.blade.php ENDPATH**/ ?>