    <!-- Preloader -->
    <div id="preloader">
        <div class="preloader">
          <span></span>
          <span></span>
        </div>
      </div>
      <!-- End Preloader -->

<!-- back to top start -->
<div class="progress-wrap">
    <svg
      class="progress-circle svg-content"
      width="100%"
      height="100%"
      viewBox="-1 -1 102 102"
    >
      <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
    </svg>
</div>
<!-- back to top end -->



    <!-- Mobile Menu Button -->
    <button
      type="button"
      class="mobile-menu-offcanvas-toggler"
      data-bs-toggle="modal"
      data-bs-target="#offcanvas-modal"
    >
      <span class="line"></span>
      <span class="line"></span>
      <span class="line"></span>
    </button>
    <!-- End Mobile Menu Button -->



<!-- Header -->


    <!-- Header Area -->
    <header class="header-area" id="active-sticky">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="header-menu">
                <nav class="navigation">
                  <ul id="nav" class="header-menu-list">
                    <li class="active"><a href="#home">Home</a></li>
                    <li><a href="#about">About me</a></li>
                    <li><a href="#experience">Expertise area</a></li>
                    <li><a href="#testimonial">Testimonials</a></li>
                    <li><a href="#business-solution">Business solution</a></li>
                    <li><a href="#photography">Photography</a></li>
                    <li><a href="#blog">Blog</a></li>
                    <li><a href="#contact">Contact us</a></li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </header>
      <!-- End Header Area -->
<?php /**PATH H:\GetUp\project\portfolio-v2\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>